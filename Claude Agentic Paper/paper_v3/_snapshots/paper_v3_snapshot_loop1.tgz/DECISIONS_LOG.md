# Decisions log — THz multilayer extraction paper, 8-page revision

Director: Fable (Claude). Agents: Writer, Coder, Domain Reviewer, Outside Reviewer.
Format of an entry: **ID · date · raised by** — issue · positions · **Director's ruling** · rationale.
Disagreements between agents are logged verbatim (summarised) under "Disagreements"; director rulings under "Rulings".

## Brief (from Vasilis, 2026-11-23)
Goal: show the limits and capabilities of the transfer-matrix method combined with modern solvers for THz material-parameter extraction; show the typical loss profile of a THz problem and how Adam and L-BFGS converge to it; demonstrate thin-film extraction up to the limits of the method.
1. Reduce the existing paper to 8 pages (Optica template).
2. Verify all references.
3. No gratuitous numbers in prose; numbers live in tables, figures or captions unless needed for an argument.
4. Deliver all Python as notebooks that regenerate every paper figure.
5. Remove Bayesian seeding everywhere; one remark that it was used and was not efficient.
6. Combine with thin-film experimental data (polyimide on Si).
7. Sec 6.3 Cramér–Rao in more detail: why κ₂ < 0 is a model artefact, step by step.
8. Sec 6.4: softplus to bound κ ≥ 0, a few lines of text only; remove old Figs 6 and 7.
9. Sec 7: emphasis on L-BFGS vs Adam, not on the loss function; new figure like old Fig. 5 showing the L-BFGS trajectory to the minimum.
10. Sec 8: three-layer quartz–air–silicon, six frequency knots for quartz and silicon.
11. Ask questions in between.  12. Record disagreements between agents.

## Rulings

**R1 · 2026-11-23 · user** — Pipeline run as sub-agents in this session (writer, coder, two reviewers, director), three review loops. Logs and outputs go to `Claude Agentic Paper/paper_v3/`.

**R2 · 2026-11-23 · user** — Starting manuscript is `main_2.tex` with all marked changes accepted (`main_v2_accepted.tex`, 20 pp. with the Optica class). The thin-film limits study therefore uses the measured reference pulse and measured noise.

**R3 · 2026-11-23 · user** — Section 8 uses quartz–air–Si **run 3** (15 min, 21 Oct 2026). Only the six-knot (frequency-grid) model is presented; the polynomial model is not mentioned anywhere.

**R4 · 2026-11-23 · user** — Five-layer simulation: keep one very short paragraph and the (small) figure; drop Table 1. If the page budget requires it in a later loop, the five-layer section may disappear entirely.

**R5 · 2026-11-23 · director** — No L-BFGS trajectory notebook exists in either folder (the user asked which file is "the BFGS"). `RobustExtractor.py` contains the only L-BFGS implementation (coarse-to-fine, scaled parameters). The coder writes a new notebook that runs torch L-BFGS (strong-Wolfe) on the **same** scaled parameters, loss and three starts as the Adam fit of the quartz/Si data, records every iterate, and projects the paths onto the same PCA planes as the Adam figure.

**R6 · 2026-11-23 · director** — Thin-film experimental data = polyimide on Si (`PI_silicon_15min.txt`, `PI_silicon_ref_15min.txt`; profilometer thickness 24.7 µm, white-light n∥(633 nm) = 1.726 from the project notes). It is presented as the experimental counterpart of the simulated thin-film sweep: the film's round trip (~0.3 ps) sits at the threshold the sweep identifies, so the extraction is expected to be marginal in n and d and good in n·d. Only one measurement (the 15-min pair in the paper folder) is in the paper folder; the earlier two-orientation notebook is used as background only.

**R7 · 2026-11-23 · director** — All Bayesian code paths are removed from the notebooks. Multi-start is kept (several starts around the nominal guess, best loss kept). The paper states once, in Sec 3, that Bayesian seeding was tried and abandoned because in 15 dimensions it moved the start into the wrong echo-assignment basin and cost more forward evaluations than it saved (project diagnosis of 2026-11-05).

**R8 · 2026-11-23 · director** — Old Fig. 6 (pair slices) and old Fig. 7 (constrained κ) are removed. The softplus constrained fit is still run, but reported only in a table row and a few lines.

**R9 · 2026-11-23 · director** — Section 7 keeps a single sentence on the combined time+frequency loss (it adds no information, Cramér–Rao bounds identical); the section is about Adam vs L-BFGS: function evaluations to convergence, path in the PCA plane, and where each lands along the n·d valley.

**R10 · 2026-11-23 · director** — Every number printed in a table, caption or in the prose must be traceable to a `results/*.json` written by one of the delivered notebooks. The domain reviewer is required to check this.

## Disagreements (agent ↔ agent, with director ruling)
_(filled during the loops)_

## Open questions for the authors
_(filled during the loops)_

**R11 · 2026-11-23 · user (question raised by coder)** — L-BFGS result reported as found: on the MAE + log-cosh loss L-BFGS completes the Phase-I descent in ~30 iterations (250–300 evaluations), reaching the loss level that Adam reaches after ~5000 iterations, then stalls at a kink of the non-smooth loss 3.7 % above Adam's end point with κ_Si still positive; on a smooth loss (rMSE, log-cosh) it converges without a stall to another point on the n·d valley. Section 7 presents this as the honest comparison; the old manuscript's claim that L-BFGS "reached the Adam level" is withdrawn.

**R12 · 2026-11-23 · director** — Canonical noise floor σ = standard deviation of the first 10 ps (pre-pulse) of the *sample* trace for every experimental fit, and of the reference trace for the simulated sweep (which has no sample trace). Consequences: quartz/Si σ = 2.9e-4 (old manuscript 2.4e-4), so MAE/σ = 15 (old 18) and |κ_Si|/CR-bound = 77 (old "ninety"). All text numbers follow the JSONs.

**R13 · 2026-11-23 · director (from refs verifier)** — `Greenall2017` could not be found as a journal article (only a Leeds PhD thesis 2017 and IRMMW-THz 2-page papers exist). Dropped from the manuscript; listed as an author question (replace with the thesis or an IRMMW-THz paper if the authors want it). `Kingma2017` corrected to ICLR 2015; `Mockus1978` to @incollection; `Yasui2005` second author Takashi Yasuda; full author lists restored where "and others" was used.

**R14 · 2026-11-23 · director (writer deviation)** — The writer removed Sec 4.1 and `fig1_five_layer` for the page budget (allowed by R4). Ruling: try to restore the five-layer figure at half width with a one-sentence paragraph in loop 1 once the real figures are placed; if the paper then exceeds 8 pages, it goes.

**R15 · 2026-11-23 · director** — Extras produced by the coder (`fig_sensitivity`, `fig8_qas_scans`) are not separate figures in the paper: the sensitivity spectrum is a panel of the two-phase figure if it fits, otherwise its numbers appear in the text/caption; the air-gap loss scan is mentioned in one sentence (air gap far better conditioned than the per-layer n–d split) with the number from nb5.json.
