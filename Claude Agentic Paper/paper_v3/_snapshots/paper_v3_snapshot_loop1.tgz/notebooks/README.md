# Notebooks that regenerate every figure of the paper

Run from this directory (`notebooks/`); every notebook adds `../code` to `sys.path` and uses the relative paths
`../data`, `../figs`, `../results`.  Execute all of them with

```
jupyter nbconvert --to notebook --execute --inplace --ExecutePreprocessor.timeout=-1 nb*.ipynb
```

Order: nb3 before nb4 (nb4 reads `results/nb3_trajectories.npz`); the others are independent.
Every fit runs in float64.  No Bayesian optimisation anywhere; multi-start around the nominal guess instead.
Figures are written as PNG (300 dpi) **and** PDF at their final single-column size (13.3 cm wide), with the shared
style of `code/paperstyle.py`.  Every number that can appear in the paper is in the `results/*.json` files.

| notebook | content | figures | results |
|---|---|---|---|
| `nb1_five_layer_simulation.ipynb` | synthetic pulse, five-layer stack, 15 parameters, coarse-to-fine L-BFGS from a hand guess (4 starts) | `fig1_five_layer` | `nb1.json` |
| `nb2_thin_film_limits_and_PI.ipynb` | A: film-thickness sweep 5–100 µm with the measured reference pulse and measured noise (3 draws, 5 starts); B: polyimide on Si, multi-start fit, secondary minimum, Cramér–Rao bounds, comparison with profilometer / visible index | `fig2_thin_film` | `nb2.json`, `nb2_cache.npz` |
| `nb3_quartz_si_adam_landscape.ipynb` | quartz/Si Adam fit (3 starts, 20 000 it.), sensitivity matrix, Cramér–Rao bounds and the κ₂-sign argument, softplus-constrained fit, two-phase PCA landscape | `fig3_exp_fit`, `fig4_adam_two_phase`, `fig_sensitivity` | `nb3.json`, `nb3_trajectories.npz`, `nb3_cache.npz` |
| `nb4_lbfgs_vs_adam.ipynb` | L-BFGS (strong Wolfe, history 20) on the same parameters / loss / starts, every iterate recorded, projected on the planes of Fig. 4; MAE, rMSE and log-cosh losses for robustness | `fig5_lbfgs_trajectory` | `nb4.json` |
| `nb5_quartz_air_si_six_knots.ipynb` | quartz / air / Si run 3, six-knot n(f), κ(f) per layer, two-stage Adam fit (15 000 + 30 000 it.), loss scans | `fig6_qas_fit`, `fig7_qas_nk`, `fig8_qas_scans` (optional panel) | `nb5.json`, `nb5_cache.npz` |

Run times on two CPU cores (float64): nb1 ≈ 1 min, nb2 ≈ 4 min, nb3 ≈ 9 min, nb4 ≈ 3 min, nb5 ≈ 9 min.
nb2, nb3 and nb5 have a `RUN_FULL` flag (default `True`); set it to `False` to reload the cached fits from
`results/*_cache.npz` and only redo the analysis and figures.

Code in `code/` used by the notebooks: `Simulate.py` (synthetic pulse), `RobustExtractor.py` (float64 forward model,
scaled parameters, coarse-to-fine L-BFGS), `quartzsi_model.py` (quartz/Si problem shared by nb3 and nb4),
`loss_landscape_viz.py` (PCA planes, phase split, landscape drawing), `dispersive_grid64.py` (float64 six-knot
model, transcription of `dispersive_multilayer_grid.py`), `paperstyle.py` (figure style).
