% Script to analyse data provided by the THz Scanner in realtime
% AUTHOR - Sam BERRY <berry.sam@gmail.com>

% INPUTS needed
% mode - The output data mode
%   1: Histogram style average
% 
% t, signal, resolution

% OUTPUS
% bin_data


% Reconstruct the workspace of the Scanner
close all
clear all
load('073516-891.mat')

% We need to create a new time vector using the resolution specified
tmin = min(t);
tmax = max(t);

trange = tmax - tmin;
dt = trange/resolution;

% Create the processed time vector
tp = (tmin: dt :tmax) + dt/2;
tp(resolution+1) = [];

bin_data = zeros(size(tp));
bin_count = zeros(size(tp));

Dt = dt/2;
temp = 0;
for ii = 1:length(bin_data)
    temp = signal(find(t >= tp(ii)-Dt & t < tp(ii)+Dt));
    bin_data(ii) =  bin_data(ii) + sum(temp);
    bin_count(ii) = bin_count(ii) + length(temp);
end

plot(tp,bin_data./bin_count)